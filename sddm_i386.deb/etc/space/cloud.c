
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dlfcn.h>
#include <termios.h>
#include <fcntl.h>
#include <pthread.h>

#include "dohighdata.h"
#include "XG_Protocol.h"





void main()
{

    FILE   *stream;
    FILE   *stream1;
   // char  *buf[1024];
   // char  *buf1[1024];
    char *dev="usb";
    char *devNo="1";
    int ret = 1;
    char *method="verify";
    char *name = "3";
    system("sudo zenity  --info --title=\"指静脉验证\" --text=\“请放手指\" --width=200 --height=150 ");
    space_vein_init();
    space_veindev_data_get(dev,ret);
    getiDevAdr(devNo);
    space_vein_init();
    int i= verify_Data(method,3);

        
    if(1==i)
	{
        system("sudo mount -t nfs 192.168.31.142:/home/hui/cloud /home/share/cloud ");
        system("sudo dolphin  /home/space/云盘 >/dev/null 2>&1");
    }
    else 
    {
        
        system("zenity  --info --title=\"失败\" --text=\"验证失败\" --width=200 --height=150 >/dev/null 2>&1 ");
     
    }



























/*

 // pthread_t identifyTid;
    char *dev="usb";
    char *devNo="1";
    //char input[255];
    int ret = 1;
    char *method="enroll";
    char *name="3";
   // printf("000000\n");
    //int t= snprintf(mode, strlen("1")+1, "%s", "1");
    // printf("mode is %s %d \n",mode,t);
     space_vein_init();
     space_veindev_data_get(dev,ret);
     //printf("000000\n");
     getiDevAdr(devNo);
     //printf("000000\n");
    enroll_Data(method,name);

 //	 int i= verify_Data("verify",3);
//	printf("vein back:%d\n",i);


*/

     }



