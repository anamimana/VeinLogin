#include <errno.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dlfcn.h>
#include <termios.h>
#include <fcntl.h>
#include <pthread.h>

#include "dohighdata.h"
#include "XG_Protocol.h"

void *mount_cloud();
void *vein_verify();

int result = 0;
char *method="verify";
char *name = "3";
FILE *fd, *fm;

int  main()
{

    int ret = 0;
    pthread_t pt_mount, pt_vein; //创建两个线程一个用来挂载云盘，一个用来验证指静脉
    
    ret = pthread_create(&pt_vein, NULL, (void*)vein_verify, NULL);
    if(-1 == ret) 
    {
        printf("create pthread failed!\n");
        return -1;
    }
    
    pthread_join(pt_vein, NULL);

    if(1==result)
	{
        ret = pthread_create(&pt_mount, NULL, (void*)mount_cloud, NULL);
        if(-1 == ret) 
        {
            printf("create pthread failed!\n");
            return -1;
        }

        pthread_join(pt_mount, NULL);
        printf("before dolphin\n");
        system("dolphin  /home/space >/dev/null 2>&1");

    } else {
        system("zenity  --info --title=\"失败\" --text=\"验证失败\" --width=200 --height=150 >/dev/null 2>&1 ");
    }

    return 0;
}



void *mount_cloud() //挂载云盘 
{
    fm = popen("sudo mount -t nfs 192.168.31.142:/home/hui/cloud /home/share/cloud ","r");
}

void *vein_verify() //验证指静脉 
{
    char *dev="usb";
    char *devNo="1";
    int ret = 1;

    system("yad  --info --title=\"指静脉验证\" --text=\"确认后请放入手指\" --licon='/usr/share/space/img_resource/clock.png' --image='/etc/space/finger.jpg' --width=200 --height=150 >/dev/null 2>&1 ");
    space_vein_init();
    space_veindev_data_get(dev,ret);
    getiDevAdr(devNo);
    space_vein_init();
    result= verify_Data(method,3);
    pthread_exit( NULL);
} 

