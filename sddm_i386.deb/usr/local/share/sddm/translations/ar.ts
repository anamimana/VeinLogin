<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>مرحبًا بك في %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>تحذير، مفتاح Caps Lock مفعّل!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>التّخطيط</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>لِج</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>فشل الولوج</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>نجح الولوج</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>كلمة المرور</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>أدخل اسم المستخدم وكلمة مروره</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>أعد الإقلاع</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>الجلسة</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>أطفئ</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>اسم المستخدم</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>اختر مستخدمًا وأدخل كلمة مروره</translation>
    </message>
</context>
</TS>
