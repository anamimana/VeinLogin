<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Bienvenue à %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Attention, la touche Verr Maj est activée !</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Configuration</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Identification</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Échec de l&apos;identification</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Identification réussie</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Entrez votre identifiant et mot de passe</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Redémarrer</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Éteindre</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Sélectionnez votre identifiant et entrez votre mot de passe</translation>
    </message>
</context>
</TS>
