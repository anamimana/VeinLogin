<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Hoş Geldiniz (%1)</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Uyarı, Caps Lock AÇIK! </translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Klavye Düzeni</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Giriş</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Giriş başarısız</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Giriş başarılı</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Parola</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Kullanıcı adınızı ve parolanızı giriniz</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Yeniden Başlat</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Oturum</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Kullanıcı adı</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Kullanıcınızı seçiniz ve parolanızı giriniz</translation>
    </message>
</context>
</TS>
