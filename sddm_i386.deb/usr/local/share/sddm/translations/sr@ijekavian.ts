<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sr@ijekavian">
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Добро дошли у %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Упозорење, укључена су велика слова!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Распоред</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Пријава</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Пријава није успјела</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Пријава успјешна</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Лозинка</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Унесите ваше корисничко име и лозинку</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Покрени поново</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Сесија</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Угаси</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Корисничко име</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Изаберите корисника и унесите лозинку</translation>
    </message>
</context>
</TS>
